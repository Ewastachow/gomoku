module Board where

import Data.String
import Data.List
import Control.Lens


alphabet = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","W","Y","Z"]

data Part = X | O | E deriving Eq

instance Show Part where
    show X = "X"
    show O = "O"
    show E = "_"

data Board = Board { board::[[Part]] }

instance Show Board where
      show (Board arr) = showBoardAll arr


-- ###################################################################
-- ##########     Init Board     #####################################
-- ###################################################################

initNewBoard:: Int -> Board
initNewBoard size = initBoard size E

initBoard:: Int -> Part -> Board
initBoard size u = Board [ [ u | x <- [0..size-1] ] | y <- [0..size-1]]


-- ###################################################################
-- ##########     Show Board     #####################################
-- ###################################################################

showBoardAll:: [[Part]] -> String        
showBoardAll arr =
    "     " ++ showFirstLine 0 (length arr) ++ "\n" ++ showBoard 1 arr

showFirstLine:: Int -> Int -> String    
showFirstLine it size
    | it < size = (alphabet !! it) ++ " " ++ showFirstLine (it+1) size
    | it >= size = ""

showBoard:: Int -> [[Part]] -> String
showBoard it [] = ""
showBoard it (x:xs) = 
    showLineLn it x ++ showBoard (it+1) xs

showLineLn:: Int -> [Part] -> String
showLineLn it xs 
    | it < 10 = " " ++ show it ++ ":  " ++ showLine xs ++ "\n"
    | it >= 10 = show it ++ ":  " ++ showLine xs ++ "\n"

showLine:: [Part] -> String
showLine [] = ""
showLine (s:xs) =
    show s ++ " " ++ showLine xs     


-- ###################################################################
-- ##########     Are Coords Valid     ###############################
-- ###################################################################

areCoordsValid:: Int -> Int -> Int -> Int -> Bool
areCoordsValid size x y = (isValidCoord size x) && (isValidCoord size y)

isValidCoord:: Int -> Int -> Bool
isValidCoord size x = (x >= 0) && (x < size)


-- ###################################################################
-- ##########     Insert In Board     ################################
-- ###################################################################

insertInRow arr y u = (element y .~ u) arr

insertInBoard (Board arr) x y u = Board $ (element x .~ insertInRow (arr !! x) y u) arr

insertInEmpty (Board arr) x y u 
	|((arr !! x) !! y) == E = insertInBoard (Board arr) x y u
	|((arr !! x) !! y) /= E = (Board arr)

insertBattle (Board arr) x y u
	|((x >= 0 ) && (x < (length arr)) && (y >= 0 ) && (y < (length arr))) = insertInEmpty (Board arr) (x - 1) (y - 1) u
	|((x < 0 ) || (x >= (length arr)) || (y < 0 ) || (y >= (length arr))) = (Board arr)

----------------------------------------------------------------------

insertToBoard (Board arr) x y u 
	| (areCoordsValid (length arr) x y) = Board (insertToArr arr x y u)
	| otherwise = Board arr

insertToArr arr posX posY u = [[ (insertPart arr x y posX posY u) | x <- [0..(length arr)-1] ] | y <- [0..(length arr)-1]]

insertPart arr x y posX posY u 
	| (x /= posX) || (y /= posY) = ((arr !! y) !! x)
	| (x == posX) && (y == posY) && (((arr !! y) !! x) == E) = u
	| otherwise = ((arr !! y) !! x)

-- ###################################################################
-- ##########     Is Won     #########################################
-- ###################################################################

finish board = ((won board X) || (won board O))

won arr u = wonBoard (board arr) (board arr) u 0

wonBoard _ [] _ _ = False
wonBoard arr (x:xs) u it = ((wonLine arr it arr u 0) || (wonBoard arr xs u (it+1)))

wonLine _ _ [] _ _ = False
wonLine arr x (y:ys) u it = ((hasFive arr x it u) || (wonLine arr x ys u (it+1)))

hasFive arr x y u
	|((arr !! x) !! y) == u = ((hasFiveVertical arr x y u 5) || (hasFiveHorizontally arr x y u 5) || (hasFiveBias arr x y u 5))
	|((arr !! x) !! y) /= u = False

hasFiveVertical _ _ _ _ 0 = True
hasFiveVertical arr x y u it 
	|y >= 0 = ((((arr !! x) !! y) == u) && (hasFiveVertical arr x (y-1) u (it-1)))
	|y < 0 = False

hasFiveHorizontally _ _ _ _ 0 = True
hasFiveHorizontally arr x y u it 
	|x >= 0 = ((((arr !! x) !! y) == u) && (hasFiveHorizontally arr (x-1) y u (it-1)))
	|x < 0 = False

hasFiveBias _ _ _ _ 0 = True
hasFiveBias arr x y u it 
	|((x >= 0) && (y >= 0)) = ((((arr !! x) !! y) == u) && (hasFiveBias arr (x-1) (y-1) u (it-1)))
	|((x < 0) || (y < 0)) = False
